<template>
  <div :class="$style.wrap" />
</template>
<style module lang="postcss">
.wrap {
  position: fixed;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  background: rgba(0, 0, 0, .4);
}
</style>
