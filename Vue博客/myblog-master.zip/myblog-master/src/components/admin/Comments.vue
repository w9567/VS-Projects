<template>
    <section class="blog-body" style="text-align:center">
        Nothing
    </section>
</template>
<script>
export default {
    
}
</script>
