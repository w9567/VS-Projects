<template>
  <footer>wqwqwq</footer>
</template>
<style scoped>
footer {
  border-top: 1px solid #ebeef5;
  height: 30px;
  line-height: 30px;
  text-align: center;
  font-size: 12px;
  max-width: 770px;
  margin:0 auto;
  color: #C0C4CC;
  margin-top: 15PX;
}
</style>
