# vue-order-calendar
# Vue日历组件

  A calendar component with a predetermined function<br>
  一个有预定功能的日历组件

- **基本日历** ：基本日历显示，代码简洁；


![](https://github.com/herozhou/vue-order-calendar/blob/master/vue-order-calendar/img/%E5%9F%BA%E6%9C%AC%E5%8A%9F%E8%83%BD%E6%95%88%E6%9E%9C.png)  

- **预定功能** ：适用于电影院、车票、演唱会等；

![](https://github.com/herozhou/vue-order-calendar/blob/master/vue-order-calendar/img/%E9%A2%84%E5%AE%9A%E5%8A%9F%E8%83%BD%E6%95%88%E6%9E%9C%E5%9B%BE.png) 

- **管理功能** ：管理员在后台批量修改；

![](https://github.com/herozhou/vue-order-calendar/blob/master/vue-order-calendar/img/%E7%AE%A1%E7%90%86%E7%95%8C%E9%9D%A2%E6%95%88%E6%9E%9C%E5%9B%BE.png)  
