export const SET_AUDIOELE = 'SET_AUDIOELE' // 修改audio元素
export const SET_PLAYMODE = 'SET_PLAYMODE' // 修改播放模式
export const SET_PLAYING = 'SET_PLAYING' // 修改播放状态
export const SET_PLAYLIST = 'SET_PLAYLIST' // 修改播放列表
export const SET_ORDERLIST = 'SET_ORDERLIST' // 修改顺序列表
export const SET_CURRENTINDEX = 'SET_CURRENTINDEX' // 修改当前音乐索引
export const SET_HISTORYLIST = 'SET_HISTORYLIST' // 修改播放历史列表
export const SET_UID = 'SET_UID' // 修改网易云用户UID
