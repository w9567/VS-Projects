package com.jiguiyan.domain;

import com.jiguiyan.vo.PrimaryKey;

public class Praise {

	private PrimaryKey primaryKey;

	public PrimaryKey getPrimaryKey() {
		return primaryKey;
	}

	public void setPrimaryKey(PrimaryKey primaryKey) {
		this.primaryKey = primaryKey;
	}
	
	

	
}
