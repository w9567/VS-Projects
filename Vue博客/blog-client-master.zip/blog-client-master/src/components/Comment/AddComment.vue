<template>
  <CommentForm operate="add" />
</template>
<script>
import CommentForm from './CommentForm'

export default {
  components: {
    CommentForm
  }
}
</script>
